"""Drive_robot controller."""
#as our supervisor suggested at the beggining of the project
#the robot will use 2 wheel differential drive
#this will allow us to learn the theory and language
#aswell as the structure of building and creating
#robotics simulastion 

from controller import Robot

if __name__ == "__main__":

    # create the Robot instance.
    robot = Robot()
    
    # get the time step of the current world.
    timestep = 64
    max_speed = 6.28
    # we make two veriables and assigment it the correct mootor
    #but using the getMotor function
    left_motor = robot.getMotor('motor_1')
    right_motor = robot.getMotor('motor_2')
    
    #we grab both of the motors and we set their position to infinity
    #and their Velocity to 0
    left_motor.setPosition(float('inf'))
    left_motor.setVelocity(0.0)
    
    right_motor.setPosition(float('inf'))
    right_motor.setVelocity(0.0)
    
    #to make the robot not driving into the wall of the arena
    #we gonna make the robot drive in a square shape
    #we achive this with the following calculastion
    number_sides = 4
    length_side = 0.25
    
    wheel_radius = 0.025
    l_velocity = wheel_radius * max_speed
    
    duration_side = length_side/l_velocity
    
    starting_time = robot.getTime()
    
    angle_of_rotation = 6.28/number_sides
    distance_between_wheels = 0.090
    rate_of_rotation = (2 * l_velocity)/distance_between_wheels
    duration_turn = angle_of_rotation/rate_of_rotation
    
    rot_start_time = starting_time + duration_side
    rot_end_time = rot_start_time + duration_turn
    
    # Main loop:
    # - perform simulation steps until Webots is stopping the controller
    while robot.step(timestep) != -1:
        
        current_time = robot.getTime()
    
    
    #we calculate the speeds of each wheel
        left_wheel_speed =  max_speed
        right_wheel_speed =  max_speed
        
        #we use the if statmets to check when the robot has to turn 
        #inroder to turn we make one of the wheels start rotating
        #in a oppositve way another way to achive this effect less 
        #aggresively will be to adjust to speed to be slower then the
        #right wheel
        if rot_start_time < current_time < rot_end_time:
            left_wheel_speed = -max_speed
            right_wheel_speed = max_speed
        
        elif current_time > rot_end_time:
            rot_start_time = current_time + duration_side
            rot_end_time = rot_start_time + duration_turn
        
    #we set the corresponding speeds to their motors
        left_motor.setVelocity(left_wheel_speed)
        right_motor.setVelocity(right_wheel_speed)
    
    
      
      
    
    # Enter here exit cleanup code.
    