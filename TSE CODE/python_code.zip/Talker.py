#!/usr/bin/env python

import rospy
import keyboard
from std_msgs.msg import String
   
def talker():
    pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():

    
        while True:
            if keyboard.read_key() == "w":
                forward_str = "speed = 1" % rospy.get_time()
                rospy.loginfo(right_str)
                pub.publish(right_str)
                rate.sleep()
                break

        while True:
            if keyboard.read_key() == "s":
                back_str = "speed = -1" % rospy.get_time()
                rospy.loginfo(back_str)
                pub.publish(back_str)
                rate.sleep()
                break

        while True:
            if keyboard.read_key() == "d":
                right_str = "x = 90" % rospy.get_time()
                rospy.loginfo(right_str)
                pub.publish(right_str)
                rate.sleep()
                break

        while True:
            if keyboard.read_key() == "a":
                left_str = "x = -90" % rospy.get_time()
                rospy.loginfo(left_str)
                pub.publish(left_str)
                rate.sleep()
                break
  
if __name__ == '__main__':
    try:
        talker()
        except rospy.ROSInterruptException:
            pass
